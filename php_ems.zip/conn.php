<?php 

$conn = mysqli_connect('localhost','root','','demo');

if(!$conn){
    die('ERROR DATABASE');
}

?>